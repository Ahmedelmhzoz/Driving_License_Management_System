﻿using System;
using System.Drawing;
using System.Windows.Forms;
using BusinessLayer;
using BusinessLayer.License_Applications;
using Shared;

namespace PresentationLayer.Local_License_Appliaction {
    public partial class FrmIssueLocalLicense : Form {
        LocalLicenseIssuingApp licenseApp = null;
        public FrmIssueLocalLicense(LocalLicenseIssuingApp licenseApp) {
            InitializeComponent();
            this.licenseApp = licenseApp;
        }
        private void FrmIssueLocalLicense_Load(object sender, EventArgs e) {
            ucLocalDrivingLicenseDetails1.loadData(licenseApp);
            lblFees.Text = '$' + licenseApp.LicenseClassInfo.classFees.ToString("0.##");
        }
        private void btnIssueLicense_Click(object sender, EventArgs e) {
            Driver Driver = null;
            if (!Driver.isPersonAlreadyDriver(licenseApp.personID)) {
                Driver = new Driver();
                Driver.creationDate = DateTime.Now;
                Driver.createdByUserID = ImportantSessionData.user.userID;
                Driver.personID = licenseApp.personID;
                if (!Driver.Save()) {
                    Alert.ShowErrorMessage("Error happend while saving driver");
                    return;
                }
            } else {
                Driver = Driver.findDriverByPersonID(licenseApp.personID);
            }
        

            LocalLicense newLicense = new LocalLicense();
            newLicense.ApplicationID = licenseApp.AppID;
            newLicense.DriverID = Driver.driverID;
            newLicense.LicenseClassID = licenseApp.LicenseClassID;
            newLicense.IssueDate = DateTime.Now;

            byte validityLength = licenseApp.LicenseClassInfo.DefaultValidityLength;
            newLicense.ExpirationDate = DateTime.Now.AddYears(validityLength);

            newLicense.Notes = txtNotes.Text;
            newLicense.PaidFees = licenseApp.LicenseClassInfo.classFees;
            newLicense.NotSuspended = true;
            newLicense.IssueReason = enIssueReason.enFirstTime;
            newLicense.CreatedByUserID = ImportantSessionData.user.userID;
            if (newLicense.Save()) {
                Alert.SuccessfulMessage("License issued successfully!");
                licenseApp.appStatus = enApplicationStatus.enCompleted;
                licenseApp.lastStatusDate = DateTime.Now;
                if (!licenseApp.SaveApplication()) {
                    Alert.ShowErrorMessage("Error happend while saving license app status!");
                    return;
                }

                lblLicenseID.Text = newLicense.LicenseID.ToString();
                lblLicenseID.BackColor = Color.SpringGreen;
                btnIssueLicense.Enabled = false;
            }
            else {
                Alert.ShowErrorMessage("Error happend while saving license!");
            }
        }
    }
}
