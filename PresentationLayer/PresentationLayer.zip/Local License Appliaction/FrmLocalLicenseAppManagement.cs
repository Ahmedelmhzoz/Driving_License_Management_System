﻿using BusinessLayer;
using BusinessLayer.License_Applications;
using PresentationLayer.Licenses;
using PresentationLayer.Local_License;
using PresentationLayer.Local_License_Appliaction;
using Shared;
using System;
using System.Drawing;
using System.Windows.Forms;
namespace PresentationLayer.Local_DL_Appliaction {
    public partial class FrmLocalLicenseAppManagement : Form {
        public FrmLocalLicenseAppManagement() {
            InitializeComponent();
        }
        private void _ApplyGridFormatting() {
            foreach (DataGridViewRow row in dgvLocalApplications.Rows) {
                if (row.Cells["ApplicationStatus"].Value != null) {
                    string status = row.Cells["ApplicationStatus"].Value.ToString();

                    if (status == "New") {
                        row.Cells["ApplicationStatus"].Style.ForeColor = Color.Blue;
                        row.Cells["ApplicationStatus"].Style.BackColor = Color.DeepSkyBlue;
                    }
                    else if (status == "Canceled") {
                        row.Cells["ApplicationStatus"].Style.ForeColor = Color.Red;
                        row.Cells["ApplicationStatus"].Style.BackColor = Color.Pink;
                    }
                    else {
                        row.Cells["ApplicationStatus"].Style.ForeColor = Color.Green;
                        row.Cells["ApplicationStatus"].Style.BackColor = Color.LightGreen;
                    }
                }
            }
        }
        void _loadAllApplication() {
            dgvLocalApplications.DataSource = LocalLicenseIssuingApp.getAllApplications();
            lblRecordsNo.Text = dgvLocalApplications.Rows.Count.ToString();
            _ApplyGridFormatting();
        }
        void _ReloadData() {
            if (cbFilterBy.Text == "None" || string.IsNullOrWhiteSpace(txtSearch.Text)) {
                _loadAllApplication();
            }
            else {
                dgvLocalApplications.DataSource = LocalLicenseIssuingApp.GetApplicationsSearchResult(txtSearch.Text, cbFilterBy.Text);
            }
            _ApplyGridFormatting();
            lblRecordsNo.Text = dgvLocalApplications.Rows.Count.ToString();
        }
        private void FrmLocalLicenseAppManagement_Load(object sender, EventArgs e) {
            cbFilterBy.SelectedIndex = 0;
            dgvLocalApplications.RowTemplate.Height = 70;
            _loadAllApplication();
        }
        private void cbFilterBy_SelectedIndexChanged(object sender, EventArgs e) {
            if (cbFilterBy.Text == "None") {
                txtSearch.Text = "";
                txtSearch.Visible = false;
                _ReloadData();
            }
            else {
                txtSearch.Visible = true;
                _ReloadData();
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e) {
            _ReloadData();
        }
        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e) {
            if (cbFilterBy.Text == "L.D Application ID") {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                    e.Handled = true;
                }
            }
        }
        private void btnClose_Click(object sender, EventArgs e) {
            this.Close();
        }
        private void btnAdd_Click(object sender, EventArgs e) {
            FrmSelectPersonForApp frm = new FrmSelectPersonForApp();
            frm.ShowDialog();
            _ReloadData();
        }
        private void showApplicationDetailsToolStripMenuItem_Click(object sender, EventArgs e) {
            int ID = (int)dgvLocalApplications.CurrentRow.Cells[0].Value;
            LocalLicenseIssuingApp loaclLicenseApp = LocalLicenseIssuingApp.getLocalLicenseAppByID(ID);
            if (loaclLicenseApp != null) {
                FrmLocalLicenseAppInfo frm = new FrmLocalLicenseAppInfo(loaclLicenseApp);
                frm.ShowDialog();
            }
        }

        private void editApp_Click(object sender, EventArgs e) {
            int ID = (int)dgvLocalApplications.CurrentRow.Cells[0].Value;
            LocalLicenseIssuingApp loaclLicenseApp = LocalLicenseIssuingApp.getLocalLicenseAppByID(ID);
            if (loaclLicenseApp != null) {
                FrmSelectPersonForApp frm = new FrmSelectPersonForApp(loaclLicenseApp);
                frm.ShowDialog();
                _ReloadData();
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e) {
            int ID = (int)dgvLocalApplications.CurrentRow.Cells[0].Value;
            if (LocalLicenseIssuingApp.deleteLocalLicenseApp(ID)) {
                Alert.SuccessfulMessage("Local driving license application was deleted successfully!");
                _ReloadData();
            }
            else
                Alert.ShowErrorMessage("Error happend while deleting");
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e) {
            int ID = (int)dgvLocalApplications.CurrentRow.Cells[0].Value;
            LocalLicenseIssuingApp loaclLicenseApp = LocalLicenseIssuingApp.getLocalLicenseAppByID(ID);
            if (loaclLicenseApp.cancelApplication()) {
                Alert.SuccessfulMessage("Local driving license application was canceled successfully!");
                _ReloadData();
            }
            else
                Alert.ShowErrorMessage("Error happend while canceling");
        }
        void _EnablityByStatus() {
            string status = (string)dgvLocalApplications.CurrentRow.Cells["ApplicationStatus"].Value;
            int passedExamsNum = (int)dgvLocalApplications.CurrentRow.Cells["PassedExams"].Value;
            if (status == "Completed") {
                tmsiDeleteApp.Enabled = false;
                editApp.Enabled = false;
                tsmiCancelApp.Enabled = false;
                tmsiScheduleTest.Enabled = true;
            } else if (status == "New") {
                tmsiDeleteApp.Enabled = passedExamsNum >= 1 ? false : true;
                editApp.Enabled = passedExamsNum >= 1 ? false : true;
                tsmiCancelApp.Enabled = true;
                tmsiScheduleTest.Enabled = true;
            }
            else { // canceled
                tmsiDeleteApp.Enabled = false;
                editApp.Enabled = false;
                tsmiCancelApp.Enabled = false;
                tmsiScheduleTest.Enabled = false;
                tmsiIssueLicense.Enabled = false;
            }
        }
        void _DisableAllMenus() {
            visionTestToolStripMenuItem.Enabled = false;
            writtenTestToolStripMenuItem.Enabled=false;
            streetTestToolStripMenuItem.Enabled = false;
            tmsiIssueLicense.Enabled = false;
            tmsiShowLicense.Enabled = false;
            tmsiHistory.Enabled = false;
        }
        void _EnableProcessesUnderPersonProgress(int selectedPersonID) {
            int passedExams = (int)dgvLocalApplications.CurrentRow.Cells["PassedExams"].Value;
            if (passedExams >= 0) {
                visionTestToolStripMenuItem.Enabled = true;
            }
            if (passedExams >= 1) {
                writtenTestToolStripMenuItem.Enabled = true;
            }
            if (passedExams >= 2) {
                streetTestToolStripMenuItem.Enabled = true;
            }
            string AppStatus = dgvLocalApplications.CurrentRow.Cells["ApplicationStatus"].Value.ToString();
            if (passedExams == 3 && AppStatus == "New") { 
                tmsiIssueLicense.Enabled = true;
            }
            if (passedExams == 3 && AppStatus == "Completed") {
                tmsiShowLicense.Enabled = true;
            }
            if (Driver.isPersonAlreadyDriver(selectedPersonID)) {
                tmsiHistory.Enabled = true;
            }
        }
        private void cmsApp_Opening(object sender, System.ComponentModel.CancelEventArgs e) {
            _DisableAllMenus();
            _EnablityByStatus();
            int ID = (int)dgvLocalApplications.CurrentRow.Cells[0].Value;

            LocalLicenseIssuingApp loaclLicenseApp = LocalLicenseIssuingApp.getLocalLicenseAppByID(ID);
            if (loaclLicenseApp == null) { Alert.ShowErrorMessage("Cant get loaclLicenseApp"); return; }

            
            _EnableProcessesUnderPersonProgress(loaclLicenseApp.personID);
        }

        void _ShowScheduledTestsForm(enTestType testType) {
            int ID = (int)dgvLocalApplications.CurrentRow.Cells[0].Value;
            LocalLicenseIssuingApp loaclLicenseApp = LocalLicenseIssuingApp.getLocalLicenseAppByID(ID);
            if (loaclLicenseApp != null) {
                FrmAppointments frm = new FrmAppointments(loaclLicenseApp, testType);
                frm.ShowDialog();
                _ReloadData();
            }
        }
        private void visionTestToolStripMenuItem_Click(object sender, EventArgs e) {
            _ShowScheduledTestsForm(enTestType.Vision);
        }

        private void writtenTestToolStripMenuItem_Click(object sender, EventArgs e) {
            _ShowScheduledTestsForm(enTestType.Theoretical);
        }

        private void streetTestToolStripMenuItem_Click(object sender, EventArgs e) {
            _ShowScheduledTestsForm(enTestType.Street);
        }

        private void tmsiIssueLicense_Click(object sender, EventArgs e) {
            int ID = (int)dgvLocalApplications.CurrentRow.Cells[0].Value;
            LocalLicenseIssuingApp loaclLicenseApp = LocalLicenseIssuingApp.getLocalLicenseAppByID(ID);
            if (loaclLicenseApp != null) {
                FrmIssueLocalLicense frm = new FrmIssueLocalLicense(loaclLicenseApp);
                frm.ShowDialog();
                _ReloadData();
            }
        }
        private void tmsiShowLicense_Click(object sender, EventArgs e) {
            int ID = (int)dgvLocalApplications.CurrentRow.Cells[0].Value;

            LocalLicenseIssuingApp loaclLicenseApp = LocalLicenseIssuingApp.getLocalLicenseAppByID(ID);
            if (loaclLicenseApp == null){ Alert.ShowErrorMessage("Cant get loaclLicenseApp"); return; }

            LocalLicense license = LocalLicense.GetLicenseByApplicationID(loaclLicenseApp.AppID);
            if (license == null) { Alert.ShowErrorMessage("Cant get license"); return; }

            FrmLocalLicenseDetails frm = new FrmLocalLicenseDetails(license);
            frm.ShowDialog();
        }

        private void tmsiHistory_Click(object sender, EventArgs e) {
            int ID = (int)dgvLocalApplications.CurrentRow.Cells[0].Value;

             LocalLicenseIssuingApp loaclLicenseApp = LocalLicenseIssuingApp.getLocalLicenseAppByID(ID);
            if (loaclLicenseApp == null) { Alert.ShowErrorMessage("Cant get loaclLicenseApp"); return; }

            if (loaclLicenseApp.personInfo == null) { Alert.ShowErrorMessage("Cant get Person"); return; }

            FrmLicensesHistory frm = new FrmLicensesHistory(loaclLicenseApp.personInfo);
            frm.ShowDialog();
        }
    }
}
