﻿using BusinessLayer;
using PresentationLayer.Local_License;
using Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace PresentationLayer.Detain_license {
    public partial class FrmDetainManagement : Form {
        public FrmDetainManagement() {
            InitializeComponent();
        }
        private void _ApplyGridFormatting() {
            foreach (DataGridViewRow row in dgvDetain.Rows) {
                if (row.Cells["DetaintionStatus"].Value != null) {
                    string status = row.Cells["DetaintionStatus"].Value.ToString();

                    if (status == "Detained") {
                        row.Cells["DetaintionStatus"].Style.ForeColor = Color.Red;
                        row.Cells["DetaintionStatus"].Style.BackColor = Color.Pink;
                    }
                    else if (status == "Released") {
                        row.Cells["DetaintionStatus"].Style.ForeColor = Color.Green;
                        row.Cells["DetaintionStatus"].Style.BackColor = Color.LightGreen;
                    }
                }
            }
            dgvDetain.Columns["IsReleased"].Visible = false;
        }
        void _LoadMainComboBox() {
            Dictionary<enDetainFilterBy, string> filters = new Dictionary<enDetainFilterBy, string>{
                {enDetainFilterBy.None , "None" },
                {enDetainFilterBy.DetainID, "Detain ID" },
                {enDetainFilterBy.LicenseID, "License ID" },
                {enDetainFilterBy.Fullname, "Driver's name" },
                {enDetainFilterBy.DetaintionStatus, "Detainment status" },
            };
            cbFilterBy.DataSource = new BindingSource(filters, null);
            cbFilterBy.DisplayMember = "Value";
            cbFilterBy.ValueMember = "Key";
        }
        void _LoadDetaintionStatusComboBox() {
            Dictionary<enDetaintionStatus, string> detentionStatusFilter = new Dictionary<enDetaintionStatus, string>{
                {enDetaintionStatus.Detained , "Detained" },
                {enDetaintionStatus.Released, "Released" },
            };
            cbDetaintionStatus.DataSource = new BindingSource(detentionStatusFilter, null);
            cbDetaintionStatus.DisplayMember = "Value";
            cbDetaintionStatus.ValueMember = "Key";
        }
        private void FrmDetainManagement_Load(object sender, EventArgs e) {
            dgvDetain.RowTemplate.Height = 70;
            _LoadMainComboBox();
            _LoadDetaintionStatusComboBox();
            _ReloadData();
            _ApplyGridFormatting();
        }
        private enDetainFilterBy _GetSelectedFilter() {
            var selected = (KeyValuePair<enDetainFilterBy, string>)cbFilterBy.SelectedItem;
            return selected.Key;
        }
        private enDetaintionStatus _GetSelectedStatus() {
            var selected = (KeyValuePair<enDetaintionStatus, string>)cbDetaintionStatus.SelectedItem;
            return selected.Key;
        }
        void _ExceptionHappend() {
            Alert.ShowErrorMessage("Unexpected error happend");
        }
        void _ReloadData() {
            enDetainFilterBy filter = _GetSelectedFilter();
            try {
                if (filter == enDetainFilterBy.DetaintionStatus)
                    dgvDetain.DataSource = DetainLicense.getDetentionsByDetaintionStatus(_GetSelectedStatus());
                else
                    dgvDetain.DataSource = DetainLicense.getDetentionsByFilter(filter, txtSearch.Text);
                _ApplyGridFormatting();
                lblRecordsNo.Text = dgvDetain.Rows.Count.ToString();
            }
            catch {
                _ExceptionHappend();
            }
        }
        private void cbFilterBy_SelectedIndexChanged(object sender, EventArgs e) {
            enDetainFilterBy selectedFilterEnum = _GetSelectedFilter();
            if (selectedFilterEnum == enDetainFilterBy.None) {
                txtSearch.Visible = false;
                cbDetaintionStatus.Visible = false;
            }
            else if (selectedFilterEnum == enDetainFilterBy.DetaintionStatus) {
                txtSearch.Visible = false;
                cbDetaintionStatus.Visible = true;
            }
            else {
                txtSearch.Visible = true;
                cbDetaintionStatus.Visible = false;
            }
            txtSearch.Text = "";
            _ReloadData();
        }
        private void cbDetaintionStatus_SelectedIndexChanged(object sender, EventArgs e) {
            _ReloadData();
        }
        private void txtSearch_TextChanged(object sender, EventArgs e) {
            _ReloadData();
        }
        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e) {
            enDetainFilterBy selectedFilter = _GetSelectedFilter();
            if (selectedFilter == enDetainFilterBy.LicenseID || selectedFilter == enDetainFilterBy.DetainID) {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                    e.Handled = true;
                }
            }
        }
        private void btnClose_Click(object sender, EventArgs e) {
            this.Close();
        }

        bool _IsSelectedRowReleased() {
            return Convert.ToBoolean(dgvDetain.CurrentRow.Cells["IsReleased"].Value);
        }
        private void cmsDetainment_Opening(object sender, CancelEventArgs e) {
            bool IsReleased = _IsSelectedRowReleased();
            tmsiRelease.Enabled = !IsReleased;
            tmsiReleaseDetails.Enabled = IsReleased;
        }

        private void tmsiRelease_Click(object sender, EventArgs e) {
            int licenseID = (int)dgvDetain.CurrentRow.Cells["LicenseID"].Value;
            LocalLicense license = LocalLicense.GetLicenseByID(licenseID);
            if (license == null) return;
            FrmReleaseLicense frm = new FrmReleaseLicense(license);
            frm.ShowDialog();
            _ReloadData();
        }

        private void tmsiDetainDetails_Click(object sender, EventArgs e) {
            int detainID = (int)dgvDetain.CurrentRow.Cells["DetainID"].Value;
            DetainDetails detainResult = DetainLicense.getDetainDetailsByDetainID(detainID);
            if ( detainResult == null ) return;
            FrmDetainDetails frm = new FrmDetainDetails(detainResult);
            frm.ShowDialog();
        }

        private void tmsiReleaseDetails_Click(object sender, EventArgs e) {
            int detainID = (int)dgvDetain.CurrentRow.Cells["DetainID"].Value;
            ReleaseDetails releaseDetails = DetainLicense.getReleaseDetails(detainID);
            if (releaseDetails == null) return;
            FrmReleaseDetails frm = new FrmReleaseDetails(releaseDetails);
            frm.ShowDialog();
        }

        private void btnAdd_Click(object sender, EventArgs e) {
            FrmDetainLicense frm = new FrmDetainLicense();
            frm.ShowDialog();
            _ReloadData();
        }

        private void licenseDetailsToolStripMenuItem_Click(object sender, EventArgs e) {
            int licenseID = (int)dgvDetain.CurrentRow.Cells["LicenseID"].Value;
            LocalLicense license = LocalLicense.GetLicenseByID(licenseID);
            if (license == null) return;
            FrmLocalLicenseDetails frm = new FrmLocalLicenseDetails(license);
            frm.ShowDialog();
        }
    }
}
